package moviesearch.amit.com.moviesearch.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Amit_Gupta on 5/29/16.
 */
public class Movie implements Parcelable {

    private String movieName;
    private String director;
    private String year;
    private String summary;
    private String posterLink;
    private String gener;
    private String releasedDate;
    private String actors;
    private String imDbId;
    private String ratings_imDb;
    private String type;
    private boolean isFavourite;


    public Movie(Parcel in) {
        movieName = in.readString();
        director = in.readString();
        year = in.readString();
        summary = in.readString();
        posterLink = in.readString();
        gener = in.readString();
        releasedDate = in.readString();
        actors = in.readString();
        imDbId = in.readString();
        ratings_imDb = in.readString();
        type = in.readString();
        isFavourite = in.readByte() != 0;
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    public Movie() {
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getPosterLink() {
        return posterLink;
    }

    public void setPosterLink(String posterLink) {
        this.posterLink = posterLink;
    }

    public String getGener() {
        return gener;
    }

    public void setGener(String gener) {
        this.gener = gener;
    }

    public String getReleasedDate() {
        return releasedDate;
    }

    public void setReleasedDate(String releasedDate) {
        this.releasedDate = releasedDate;
    }

    public String getActors() {
        return actors;
    }

    public void setActors(String actors) {
        this.actors = actors;
    }

    public String getImDbId() {
        return imDbId;
    }

    public void setImDbId(String imDbId) {
        this.imDbId = imDbId;
    }

    public String getRatings_imDb() {
        return ratings_imDb;
    }

    public void setRatings_imDb(String ratings_imDb) {
        this.ratings_imDb = ratings_imDb;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isFavourite() {
        return isFavourite;
    }

    public void setFavourite(boolean favourite) {
        isFavourite = favourite;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(movieName);
        dest.writeString(director);
        dest.writeString(year);
        dest.writeString(summary);
        dest.writeString(posterLink);
        dest.writeString(gener);
        dest.writeString(releasedDate);
        dest.writeString(actors);
        dest.writeString(imDbId);
        dest.writeString(ratings_imDb);
        dest.writeString(type);
        dest.writeByte((byte) (isFavourite ? 1 : 0));
    }
}
