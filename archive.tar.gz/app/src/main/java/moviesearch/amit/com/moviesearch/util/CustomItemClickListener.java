package moviesearch.amit.com.moviesearch.util;

import android.view.View;

/**
 * Created by Amit_Gupta on 5/30/16.
 */
public interface CustomItemClickListener {

    public void onItemClick(View v, int position);
}
