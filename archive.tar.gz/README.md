![Alt text](/raw/output.gif?raw=true "Home Screen")

User can perform search for movies using the OMDB search API. The search results are maintained on orientation changes.

Key Concepts/libraries used
- Fragments, Activities
- TabLayout
- RecyclerView
- Volley
- Picasso
- SQL Lite persistent stoarege API's

For Building the project, unzip the archived project, open the project with Android studio, build and load the app on the connected Android device.

Known Bugs- The Add to favourite is buggy, adding to favourite sometimes adds multiple rows on clicking the star icon. The favourite tab
does not contain the added favourite, and needs a reload of UI to show them.


